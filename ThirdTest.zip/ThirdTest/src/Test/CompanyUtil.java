package Test;

public class CompanyUtil {
 /*   public Employee randomEmployee;
public Manager randomManager;
    public static Employee makeRandomEmployee(Employee randomEmployee) {
        randomEmployee = new Employee("Bibi",((int)(Math.random()*(60-20+1)+20)),new Salary((Math.random()*(50000-1000+1)+1000), (int) (Math.random()*10000)));;
        return randomEmployee;
    }
    public Manager makeRandomManager{

    }*/
}
